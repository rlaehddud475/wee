package com.korea.team_1_kdy.vo;

public class AdminVO {
	private String admin_Id;
	private String Password;
	 private String CustomerId;
}
