package com.korea.test.common;


public class Common {

	public static class Board{
		public final static int BLOCKLIST = 10;
		
		public final static int BLOCKPAGE = 5;
	}
}

