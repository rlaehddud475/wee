package com.korea.team_1_kdy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team1KdyApplicationTests {

	@Test
	void contextLoads() {
	}

}
