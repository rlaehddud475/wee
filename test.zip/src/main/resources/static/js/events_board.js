//pageMenu변수에 controller에서 넘어온 pageMenu를 대입한다.
let pageMenu = /*[[${pageMenu}]]*/""

//pageMenu라는 id를 가진 div에 pageMenu값 넣기
$("#pageMenu").html(pageMenu);