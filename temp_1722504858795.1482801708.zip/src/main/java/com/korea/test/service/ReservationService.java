package com.korea.test.service;

import com.korea.test.vo.ReservationVO;

public interface ReservationService {

	int res_insert(ReservationVO vo);

}
