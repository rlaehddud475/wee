package com.korea.team_1_kdy.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public class ReservationMapper {

}
