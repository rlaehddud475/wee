package com.korea.team_1_kdy.vo;

public class NoticeBoardVO {
	 private int idx;
	 private String title;
	 private String content;
	 private String date;
	 private String v_count;
	 private String AuthorId;
}
