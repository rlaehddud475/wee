package com.korea.test.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminVO {					// 관리자
	private String admin_Id;
	private String Password;
	private int cus_idx;
}
