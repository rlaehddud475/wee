package com.korea.team_1_kdy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Team1KdyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Team1KdyApplication.class, args);
	}

}
