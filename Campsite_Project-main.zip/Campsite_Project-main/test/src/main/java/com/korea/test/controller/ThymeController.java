package com.korea.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import ch.qos.logback.core.model.Model;

@Controller
public class ThymeController {
	@RequestMapping("/main")
	public String mian(Model model) {	
		return "main";
	}
	
	@RequestMapping("/reservation_form")
	public String reservation(Model model) {	
		return "reservation_form";
	}
}