package com.korea.team_1_kdy.vo;

public class ReservationVO {
	private String ReservationNumber;
	private String CustomerId;
	 private int Price;
	 private String ReservationDate;
}
